#!/usr/bin/env bash

#constants

export BASE_DIR="/hpc-runner-command/ci-tests/slurm"
