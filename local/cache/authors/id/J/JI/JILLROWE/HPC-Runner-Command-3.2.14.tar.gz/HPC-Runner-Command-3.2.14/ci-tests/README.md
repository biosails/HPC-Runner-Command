There are several components of the CI testing.

1. Run a basic build/test of the libraries.
2. Test each library against a scheduler.
    a. For now we are testing against SLURM, but will soon add PBS and LSF.
