#!perl

use utf8;
package Main;

use HPC::Runner::Command;

HPC::Runner::Command->new_with_command()->execute();
