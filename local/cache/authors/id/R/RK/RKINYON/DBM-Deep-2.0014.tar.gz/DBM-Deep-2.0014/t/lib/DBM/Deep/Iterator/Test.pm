package DBM::Deep::Iterator::Test;

use strict;
use warnings FATAL => 'all';

use base qw( DBM::Deep::Iterator );

1;
__END__
