package Test02::Command::Record;

use Moose;
use MooseX::App::Command;
extends qw(Test02);


1;