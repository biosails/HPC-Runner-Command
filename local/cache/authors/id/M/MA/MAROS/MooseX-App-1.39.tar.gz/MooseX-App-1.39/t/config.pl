{
    global      => {
        global          => 123,
    },
    command_a   => {
        global          => 234,
        command_local1  => 22,
    },
}